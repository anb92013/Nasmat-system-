import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { useToast } from './use-toast';

export interface Sale {
  id: string;
  user_id: string;
  product_id: string | null;
  product_name: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  profit: number;
  created_at: string;
}

export const useSales = () => {
  const [sales, setSales] = useState<Sale[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { user } = useAuth();
  const { toast } = useToast();

  const fetchSales = useCallback(async () => {
    if (!user) {
      setSales([]);
      setIsLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('sales')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setSales(data || []);
    } catch (error: any) {
      toast({ title: 'خطأ', description: 'فشل في تحميل المبيعات', variant: 'destructive' });
    } finally {
      setIsLoading(false);
    }
  }, [user, toast]);

  useEffect(() => {
    fetchSales();
  }, [fetchSales]);

  const addSale = async (sale: Omit<Sale, 'id' | 'user_id' | 'created_at'>, updateProductQuantity?: () => Promise<void>) => {
    if (!user) return;

    try {
      const { error } = await supabase.from('sales').insert({
        ...sale,
        user_id: user.id,
      });

      if (error) throw error;
      
      // Update product quantity
      if (updateProductQuantity) {
        await updateProductQuantity();
      }
      
      await fetchSales();
      toast({ title: 'تم', description: 'تم تسجيل البيع بنجاح' });
    } catch (error: any) {
      toast({ title: 'خطأ', description: error.message, variant: 'destructive' });
    }
  };

  return { sales, isLoading, addSale, refetch: fetchSales };
};
