import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { useToast } from './use-toast';

export interface Purchase {
  id: string;
  user_id: string;
  product_id: string | null;
  product_name: string;
  quantity: number;
  unit_cost: number;
  total_cost: number;
  supplier: string | null;
  created_at: string;
}

export const usePurchases = () => {
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { user } = useAuth();
  const { toast } = useToast();

  const fetchPurchases = useCallback(async () => {
    if (!user) {
      setPurchases([]);
      setIsLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('purchases')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPurchases(data || []);
    } catch (error: any) {
      toast({ title: 'خطأ', description: 'فشل في تحميل المشتريات', variant: 'destructive' });
    } finally {
      setIsLoading(false);
    }
  }, [user, toast]);

  useEffect(() => {
    fetchPurchases();
  }, [fetchPurchases]);

  const addPurchase = async (purchase: Omit<Purchase, 'id' | 'user_id' | 'created_at'>, updateProductQuantity?: () => Promise<void>) => {
    if (!user) return;

    try {
      const { error } = await supabase.from('purchases').insert({
        ...purchase,
        user_id: user.id,
      });

      if (error) throw error;
      
      // Update product quantity
      if (updateProductQuantity) {
        await updateProductQuantity();
      }
      
      await fetchPurchases();
      toast({ title: 'تم', description: 'تم تسجيل الشراء بنجاح' });
    } catch (error: any) {
      toast({ title: 'خطأ', description: error.message, variant: 'destructive' });
    }
  };

  return { purchases, isLoading, addPurchase, refetch: fetchPurchases };
};
