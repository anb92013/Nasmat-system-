import { forwardRef } from 'react';
import { Purchase } from '@/types';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';

interface PurchaseInvoiceProps {
  purchase: Purchase;
  invoiceNumber?: string;
}

export const PurchaseInvoice = forwardRef<HTMLDivElement, PurchaseInvoiceProps>(
  ({ purchase, invoiceNumber }, ref) => {
    const formattedDate = format(new Date(purchase.date), 'dd MMMM yyyy', { locale: ar });
    const formattedTime = format(new Date(purchase.date), 'hh:mm a', { locale: ar });

    return (
      <div ref={ref} className="bg-background p-8 max-w-2xl mx-auto print:p-4" dir="rtl">
        {/* Header */}
        <div className="text-center border-b-2 border-chart-2 pb-4 mb-6">
          <h1 className="text-3xl font-bold text-chart-2 mb-2">نسمات شرقية</h1>
          <p className="text-muted-foreground">لمنتجات الحناء والسدر الطبيعية</p>
        </div>

        {/* Invoice Title */}
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold bg-chart-2 text-primary-foreground py-2 rounded-lg">
            فاتورة شراء
          </h2>
        </div>

        {/* Invoice Info */}
        <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
          <div className="space-y-2">
            <div className="flex gap-2">
              <span className="text-muted-foreground">رقم الفاتورة:</span>
              <span className="font-bold">{invoiceNumber || purchase.id}</span>
            </div>
            <div className="flex gap-2">
              <span className="text-muted-foreground">التاريخ:</span>
              <span className="font-medium">{formattedDate}</span>
            </div>
            {purchase.supplier && (
              <div className="flex gap-2">
                <span className="text-muted-foreground">المورد:</span>
                <span className="font-medium">{purchase.supplier}</span>
              </div>
            )}
          </div>
          <div className="space-y-2 text-left">
            <div className="flex gap-2 justify-end">
              <span className="font-medium">{formattedTime}</span>
              <span className="text-muted-foreground">:الوقت</span>
            </div>
          </div>
        </div>

        {/* Products Table */}
        <div className="mb-6">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-muted">
                <th className="border border-border p-3 text-right">المنتج</th>
                <th className="border border-border p-3 text-center">الكمية</th>
                <th className="border border-border p-3 text-center">تكلفة الوحدة</th>
                <th className="border border-border p-3 text-center">الإجمالي</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border border-border p-3 font-medium">{purchase.productName}</td>
                <td className="border border-border p-3 text-center">{purchase.quantity}</td>
                <td className="border border-border p-3 text-center">{purchase.unitCost.toLocaleString('ar-YE')} ر.ي.</td>
                <td className="border border-border p-3 text-center font-bold">{purchase.totalCost.toLocaleString('ar-YE')} ر.ي.</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Totals */}
        <div className="border-t-2 border-chart-2 pt-4 space-y-2">
          <div className="flex justify-between text-lg">
            <span className="text-muted-foreground">إجمالي المشتريات:</span>
            <span className="font-bold text-xl">{purchase.totalCost.toLocaleString('ar-YE')} ر.ي.</span>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 pt-4 border-t border-border text-center text-sm text-muted-foreground">
          <p>نسمات شرقية - إدارة المشتريات</p>
          <p className="mt-2">جودة طبيعية 100%</p>
        </div>

        {/* Print Styles */}
        <style>{`
          @media print {
            body * {
              visibility: hidden;
            }
            .print-invoice, .print-invoice * {
              visibility: visible;
            }
            .print-invoice {
              position: absolute;
              left: 0;
              top: 0;
              width: 100%;
            }
          }
        `}</style>
      </div>
    );
  }
);

PurchaseInvoice.displayName = 'PurchaseInvoice';
