import { forwardRef } from 'react';
import { Sale } from '@/types';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';

interface SalesInvoiceProps {
  sale: Sale;
  invoiceNumber?: string;
}

export const SalesInvoice = forwardRef<HTMLDivElement, SalesInvoiceProps>(
  ({ sale, invoiceNumber }, ref) => {
    const formattedDate = format(new Date(sale.date), 'dd MMMM yyyy', { locale: ar });
    const formattedTime = format(new Date(sale.date), 'hh:mm a', { locale: ar });

    return (
      <div ref={ref} className="bg-background p-8 max-w-2xl mx-auto print:p-4" dir="rtl">
        {/* Header */}
        <div className="text-center border-b-2 border-primary pb-4 mb-6">
          <h1 className="text-3xl font-bold text-primary mb-2">نسمات شرقية</h1>
          <p className="text-muted-foreground">لمنتجات الحناء والسدر الطبيعية</p>
        </div>

        {/* Invoice Title */}
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold bg-primary text-primary-foreground py-2 rounded-lg">
            فاتورة بيع
          </h2>
        </div>

        {/* Invoice Info */}
        <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
          <div className="space-y-2">
            <div className="flex gap-2">
              <span className="text-muted-foreground">رقم الفاتورة:</span>
              <span className="font-bold">{invoiceNumber || sale.id}</span>
            </div>
            <div className="flex gap-2">
              <span className="text-muted-foreground">التاريخ:</span>
              <span className="font-medium">{formattedDate}</span>
            </div>
          </div>
          <div className="space-y-2 text-left">
            <div className="flex gap-2 justify-end">
              <span className="font-medium">{formattedTime}</span>
              <span className="text-muted-foreground">:الوقت</span>
            </div>
          </div>
        </div>

        {/* Products Table */}
        <div className="mb-6">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-muted">
                <th className="border border-border p-3 text-right">المنتج</th>
                <th className="border border-border p-3 text-center">الكمية</th>
                <th className="border border-border p-3 text-center">سعر الوحدة</th>
                <th className="border border-border p-3 text-center">الإجمالي</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border border-border p-3 font-medium">{sale.productName}</td>
                <td className="border border-border p-3 text-center">{sale.quantity}</td>
                <td className="border border-border p-3 text-center">{sale.unitPrice.toLocaleString('ar-YE')} ر.ي.</td>
                <td className="border border-border p-3 text-center font-bold">{sale.totalPrice.toLocaleString('ar-YE')} ر.ي.</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Totals */}
        <div className="border-t-2 border-primary pt-4 space-y-2">
          <div className="flex justify-between text-lg">
            <span className="text-muted-foreground">الإجمالي:</span>
            <span className="font-bold text-xl">{sale.totalPrice.toLocaleString('ar-YE')} ر.ي.</span>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 pt-4 border-t border-border text-center text-sm text-muted-foreground">
          <p> شكراً لتعاملكم معنا</p>
          <p> 779778669للاستفسار والحجز </p>
          <p className="mt-2">نسمات شرقية - جودة طبيعية 100%</p>
        </div>

        {/* Print Styles */}
        <style>{`
          @media print {
            body * {
              visibility: hidden;
            }
            .print-invoice, .print-invoice * {
              visibility: visible;
            }
            .print-invoice {
              position: absolute;
              left: 0;
              top: 0;
              width: 100%;
            }
          }
        `}</style>
      </div>
    );
  }
);

SalesInvoice.displayName = 'SalesInvoice';
