import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { useApp } from '@/context/AppContext';
import { Button } from '@/components/ui/button';
import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  ShoppingBag,
  TrendingUp,
  FileText,
  LogOut,
  Menu,
  X,
  Flower2, // Changed Icon
  Users,
  Wallet,
  Monitor
} from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
}

const navItems = [
  { path: '/dashboard', label: 'لوحة التحكم', icon: LayoutDashboard },
  { path: '/pos', label: 'نقاط البيع (POS)', icon: Monitor },
  { path: '/inventory', label: 'المخزون', icon: Package },
  { path: '/sales', label: 'المبيعات', icon: ShoppingCart },
  { path: '/purchases', label: 'المشتريات', icon: ShoppingBag },
  { path: '/suppliers', label: 'الموردين', icon: Users },
  { path: '/expenses', label: 'المصروفات', icon: Wallet },
  { path: '/profits', label: 'الأرباح', icon: TrendingUp },
  { path: '/reports', label: 'التقارير', icon: FileText },
];

export const Layout = ({ children }: LayoutProps) => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useApp();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-background font-sans" dir="rtl">
      {/* Mobile Header */}
      <header className="lg:hidden fixed top-0 right-0 left-0 z-50 bg-card border-b border-border px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Flower2 className="h-6 w-6 text-primary" />
          <span className="font-bold text-lg text-foreground">نسمات شرقية</span>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setSidebarOpen(!sidebarOpen)}
        >
          {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </header>

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed top-0 right-0 h-full bg-card border-l border-border z-40 transition-all duration-300',
          'w-64',
          sidebarOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0',
          'lg:translate-x-0 pt-16 lg:pt-0'
        )}
      >
        {/* Logo */}
        <div className="hidden lg:flex items-center gap-3 px-6 py-6 border-b border-border">
          <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
            <Flower2 className="h-6 w-6 text-primary-foreground" />
          </div>
          <div>
            <h1 className="font-bold text-lg text-foreground">نسمات شرقية</h1>
            <p className="text-xs text-muted-foreground">نظام محاسبي</p>
          </div>
        </div>

        {/* Navigation */}
        <nav className="p-4 space-y-1 overflow-y-auto max-h-[calc(100vh-140px)]">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                'flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200',
                location.pathname === item.path
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground'
              )}
              onClick={() => setSidebarOpen(false)}
            >
              <item.icon className="h-5 w-5" />
              <span className="font-medium">{item.label}</span>
            </Link>
          ))}
        </nav>

        {/* User Info & Logout */}
        <div className="absolute bottom-0 right-0 left-0 p-4 border-t border-border bg-card">
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="font-medium text-foreground">{user?.username}</p>
              <p className="text-xs text-muted-foreground">
                {user?.role === 'admin' ? 'مدير' : 'مستخدم'}
              </p>
            </div>
          </div>
          <Button
            variant="outline"
            className="w-full justify-start gap-2"
            onClick={handleLogout}
          >
            <LogOut className="h-4 w-4" />
            تسجيل الخروج
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main
        className={cn(
          'transition-all duration-300 pt-16 lg:pt-0',
          'lg:mr-64'
        )}
      >
        <div className="p-4 lg:p-8">{children}</div>
      </main>

      {/* Overlay for mobile */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-foreground/20 z-30 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
};
