import { forwardRef } from 'react';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';

interface ProfitData {
  id: string;
  name: string;
  category: string;
  unitsSold: number;
  revenue: number;
  profit: number;
  profitPerUnit: number;
  costPerUnit: number;
  sellingPrice: number;
}

interface ProfitReportProps {
  data: ProfitData[];
  totalRevenue: number;
  totalProfit: number;
  date: Date;
}

export const ProfitReport = forwardRef<HTMLDivElement, ProfitReportProps>(
  ({ data, totalRevenue, totalProfit, date }, ref) => {
    return (
      <div ref={ref} className="bg-background p-8 max-w-4xl mx-auto print:p-4" dir="rtl">
        <div className="text-center border-b-2 border-primary pb-4 mb-6">
          <h1 className="text-3xl font-bold text-primary mb-2">نسمات شرقية</h1>
          <p className="text-muted-foreground">تقرير الأرباح التفصيلي</p>
          <p className="text-sm mt-2">تاريخ التقرير: {format(date, 'dd MMMM yyyy', { locale: ar })}</p>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-8">
          <div className="bg-muted p-4 rounded-lg">
            <p className="text-sm text-muted-foreground">إجمالي الإيرادات</p>
            <p className="text-2xl font-bold">{totalRevenue.toLocaleString('ar-YE')} ر.ي.</p>
          </div>
          <div className="bg-primary/10 p-4 rounded-lg">
            <p className="text-sm text-primary">صافي الأرباح</p>
            <p className="text-2xl font-bold text-primary">{totalProfit.toLocaleString('ar-YE')} ر.ي.</p>
          </div>
        </div>

        <table className="w-full border-collapse text-sm">
          <thead>
            <tr className="bg-muted">
              <th className="border p-2 text-right">المنتج</th>
              <th className="border p-2 text-center">المبيعات (وحدة)</th>
              <th className="border p-2 text-center">سعر البيع</th>
              <th className="border p-2 text-center">التكلفة</th>
              <th className="border p-2 text-center">الإيرادات</th>
              <th className="border p-2 text-center">الربح</th>
            </tr>
          </thead>
          <tbody>
            {data.map((item) => (
              <tr key={item.id}>
                <td className="border p-2 font-medium">{item.name}</td>
                <td className="border p-2 text-center">{item.unitsSold}</td>
                <td className="border p-2 text-center">{item.sellingPrice.toLocaleString('ar-YE')}</td>
                <td className="border p-2 text-center">{item.costPerUnit.toLocaleString('ar-YE')}</td>
                <td className="border p-2 text-center">{item.revenue.toLocaleString('ar-YE')}</td>
                <td className="border p-2 text-center font-bold text-primary">{item.profit.toLocaleString('ar-YE')}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="mt-8 pt-4 border-t text-center text-xs text-muted-foreground">
          <p>تم استخراج هذا التقرير من نظام نسمات شرقية المحاسبي</p>
        </div>
      </div>
    );
  }
);

ProfitReport.displayName = 'ProfitReport';
