import { useState } from 'react';
import { Layout } from '@/components/Layout';
import { useApp } from '@/context/AppContext';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Product, Sale } from '@/types';
import { Search, ShoppingCart, Plus, Minus, Trash2, CheckCircle, Edit2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';

interface CartItem extends Product {
  cartQuantity: number;
  customPrice?: number; // Allow custom price
}

const POS = () => {
  const { products, addSale } = useApp();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  
  // State for price editing
  const [editingItem, setEditingItem] = useState<CartItem | null>(null);
  const [newPrice, setNewPrice] = useState('');
  const [isPriceDialogOpen, setIsPriceDialogOpen] = useState(false);

  const categories = Array.from(new Set(products.map(p => p.category)));

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory;
    return matchesSearch && matchesCategory && p.quantity > 0;
  });

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        if (existing.cartQuantity >= product.quantity) {
          toast({ title: 'تنبيه', description: 'الكمية المطلوبة غير متوفرة', variant: 'destructive' });
          return prev;
        }
        return prev.map(item => 
          item.id === product.id 
            ? { ...item, cartQuantity: item.cartQuantity + 1 }
            : item
        );
      }
      return [...prev, { ...product, cartQuantity: 1, customPrice: product.sellingPrice }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === productId) {
        const newQuantity = item.cartQuantity + delta;
        if (newQuantity > item.quantity) {
           toast({ title: 'تنبيه', description: 'الكمية المطلوبة غير متوفرة', variant: 'destructive' });
           return item;
        }
        return newQuantity > 0 ? { ...item, cartQuantity: newQuantity } : item;
      }
      return item;
    }));
  };

  const openPriceDialog = (item: CartItem) => {
    setEditingItem(item);
    setNewPrice(item.customPrice?.toString() || item.sellingPrice.toString());
    setIsPriceDialogOpen(true);
  };

  const handlePriceUpdate = () => {
    if (editingItem && newPrice) {
      setCart(prev => prev.map(item => 
        item.id === editingItem.id 
          ? { ...item, customPrice: Number(newPrice) }
          : item
      ));
      setIsPriceDialogOpen(false);
      setEditingItem(null);
      toast({ title: 'تم التحديث', description: 'تم تحديث السعر بنجاح' });
    }
  };

  const totalAmount = cart.reduce((sum, item) => sum + ((item.customPrice || item.sellingPrice) * item.cartQuantity), 0);

  const handleCheckout = () => {
    if (cart.length === 0) return;

    cart.forEach(item => {
      const finalPrice = item.customPrice || item.sellingPrice;
      const sale: Sale = {
        id: crypto.randomUUID(),
        productId: item.id,
        productName: item.name,
        quantity: item.cartQuantity,
        unitPrice: finalPrice,
        totalPrice: finalPrice * item.cartQuantity,
        profit: (finalPrice - item.netPurchaseCost) * item.cartQuantity, // Recalculate profit based on actual selling price
        date: new Date(),
      };
      addSale(sale);
    });

    toast({ 
      title: 'تمت العملية بنجاح', 
      description: `تم بيع ${cart.length} منتجات بقيمة ${totalAmount.toLocaleString('ar-YE')} ر.ي.` 
    });
    setCart([]);
  };

  return (
    <Layout>
      <div className="h-[calc(100vh-100px)] flex flex-col lg:flex-row gap-4">
        {/* Products Section */}
        <div className="flex-1 flex flex-col gap-4">
          {/* Search & Filters */}
          <div className="flex gap-4 flex-wrap">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="بحث عن منتج..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10"
              />
            </div>
            <div className="flex gap-2 overflow-x-auto pb-2">
              <Button 
                variant={selectedCategory === 'all' ? 'default' : 'outline'}
                onClick={() => setSelectedCategory('all')}
                size="sm"
              >
                الكل
              </Button>
              {categories.map(cat => (
                <Button 
                  key={cat}
                  variant={selectedCategory === cat ? 'default' : 'outline'}
                  onClick={() => setSelectedCategory(cat)}
                  size="sm"
                >
                  {cat === 'henna' ? 'حناء' : cat === 'sidr' ? 'سدر' : cat}
                </Button>
              ))}
            </div>
          </div>

          {/* Products Grid */}
          <ScrollArea className="flex-1">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 pb-4">
              {filteredProducts.map(product => (
                <Card 
                  key={product.id} 
                  className="cursor-pointer hover:border-primary transition-colors"
                  onClick={() => addToCart(product)}
                >
                  <CardContent className="p-4 flex flex-col items-center text-center gap-2">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center ${product.category === 'henna' ? 'bg-green-100 text-green-700' : product.category === 'sidr' ? 'bg-yellow-100 text-yellow-700' : 'bg-blue-100 text-blue-700'}`}>
                      <span className="font-bold text-lg">{product.weightGrams}g</span>
                    </div>
                    <div>
                      <h3 className="font-medium line-clamp-1">{product.name}</h3>
                      <p className="text-sm text-muted-foreground">المخزون: {product.quantity}</p>
                    </div>
                    <p className="font-bold text-primary">{product.sellingPrice.toLocaleString('ar-YE')} ر.ي.</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </ScrollArea>
        </div>

        {/* Cart Section */}
        <Card className="w-full lg:w-96 flex flex-col h-full border-l">
          <div className="p-4 border-b bg-muted/30">
            <h2 className="font-bold text-lg flex items-center gap-2">
              <ShoppingCart className="h-5 w-5" />
              سلة المشتريات
            </h2>
          </div>
          
          <ScrollArea className="flex-1 p-4">
            <div className="space-y-4">
              {cart.length === 0 ? (
                <div className="text-center text-muted-foreground py-10">
                  السلة فارغة
                </div>
              ) : (
                cart.map(item => (
                  <div key={item.id} className="flex items-center justify-between bg-card border rounded-lg p-2">
                    <div className="flex-1">
                      <p className="font-medium text-sm">{item.name}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <p className="text-xs text-muted-foreground">
                          {(item.customPrice || item.sellingPrice).toLocaleString('ar-YE')} × {item.cartQuantity}
                        </p>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-5 w-5"
                          onClick={() => openPriceDialog(item)}
                        >
                          <Edit2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => updateQuantity(item.id, -1)}>
                        <Minus className="h-3 w-3" />
                      </Button>
                      <span className="w-6 text-center text-sm font-medium">{item.cartQuantity}</span>
                      <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => updateQuantity(item.id, 1)}>
                        <Plus className="h-3 w-3" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => removeFromCart(item.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </ScrollArea>

          <div className="p-4 border-t bg-muted/30 space-y-4">
            <div className="flex justify-between items-center text-lg font-bold">
              <span>الإجمالي:</span>
              <span>{totalAmount.toLocaleString('ar-YE')} ر.ي.</span>
            </div>
            <Button 
              className="w-full h-12 text-lg gap-2" 
              onClick={handleCheckout}
              disabled={cart.length === 0}
            >
              <CheckCircle className="h-5 w-5" />
              إتمام البيع
            </Button>
          </div>
        </Card>
      </div>

      {/* Price Edit Dialog */}
      <Dialog open={isPriceDialogOpen} onOpenChange={setIsPriceDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تعديل السعر</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>السعر الجديد</Label>
              <Input 
                type="number" 
                value={newPrice} 
                onChange={(e) => setNewPrice(e.target.value)}
                placeholder="أدخل السعر الجديد"
              />
            </div>
            <Button onClick={handlePriceUpdate} className="w-full">تحديث السعر</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Layout>
  );
};

export default POS;
