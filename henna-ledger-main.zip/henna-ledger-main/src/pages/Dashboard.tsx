import { useMemo } from 'react';
import { Layout } from '@/components/Layout';
import { useApp } from '@/context/AppContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { 
  Package, 
  ShoppingCart, 
  TrendingUp, 
  DollarSign,
  ArrowUpRight,
  ArrowDownRight,
  AlertTriangle,
  ArrowLeft
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const Dashboard = () => {
  const { products, sales, purchases } = useApp();

  const stats = useMemo(() => {
    const totalInventoryValue = products.reduce((sum, p) => sum + (p.sellingPrice * p.quantity), 0);
    const totalSales = sales.reduce((sum, s) => sum + s.totalPrice, 0);
    const totalPurchases = purchases.reduce((sum, p) => sum + p.totalCost, 0);
    const totalProfit = sales.reduce((sum, s) => sum + s.profit, 0);
    const totalProducts = products.reduce((sum, p) => sum + p.quantity, 0);

    return {
      totalInventoryValue,
      totalSales,
      totalPurchases,
      totalProfit,
      totalProducts,
    };
  }, [products, sales, purchases]);

  const lowStockProducts = useMemo(() => {
    return products.filter(p => p.quantity <= 20); // Threshold for low stock
  }, [products]);

  const categoryData = useMemo(() => {
    const hennaProducts = products.filter(p => p.category === 'henna');
    const sidrProducts = products.filter(p => p.category === 'sidr');
    
    return [
      { name: 'الحناء', value: hennaProducts.reduce((sum, p) => sum + p.quantity, 0), color: 'hsl(var(--chart-1))' },
      { name: 'السدر', value: sidrProducts.reduce((sum, p) => sum + p.quantity, 0), color: 'hsl(var(--chart-2))' },
    ];
  }, [products]);

  const salesByProduct = useMemo(() => {
    const grouped: Record<string, number> = {};
    sales.forEach(sale => {
      grouped[sale.productName] = (grouped[sale.productName] || 0) + sale.totalPrice;
    });
    return Object.entries(grouped).map(([name, value]) => ({ name, value }));
  }, [sales]);

  const statCards = [
    {
      title: 'إجمالي المبيعات',
      value: stats.totalSales.toLocaleString('ar-YE'),
      unit: 'ر.ي.',
      icon: ShoppingCart,
      trend: '+12%',
      trendUp: true,
      color: 'bg-primary',
    },
    {
      title: 'صافي الأرباح',
      value: stats.totalProfit.toLocaleString('ar-YE'),
      unit: 'ر.ي.',
      icon: TrendingUp,
      trend: '+8%',
      trendUp: true,
      color: 'bg-chart-2',
    },
    {
      title: 'قيمة المخزون',
      value: stats.totalInventoryValue.toLocaleString('ar-YE'),
      unit: 'ر.ي.',
      icon: DollarSign,
      trend: '-3%',
      trendUp: false,
      color: 'bg-chart-3',
    },
    {
      title: 'عدد المنتجات',
      value: stats.totalProducts.toLocaleString('ar-YE'),
      unit: 'وحدة',
      icon: Package,
      trend: '+5%',
      trendUp: true,
      color: 'bg-chart-4',
    },
  ];

  return (
    <Layout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">لوحة التحكم</h1>
          <p className="text-muted-foreground mt-1">نظرة عامة على أداء المتجر</p>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {statCards.map((stat, index) => (
            <Card key={index} className="overflow-hidden">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className={`p-2 rounded-lg ${stat.color}`}>
                    <stat.icon className="h-5 w-5 text-primary-foreground" />
                  </div>
                  <div className={`flex items-center gap-1 text-xs font-medium ${stat.trendUp ? 'text-primary' : 'text-destructive'}`}>
                    {stat.trend}
                    {stat.trendUp ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
                  </div>
                </div>
                <div className="mt-4">
                  <p className="text-2xl font-bold text-foreground">
                    {stat.value}
                    <span className="text-sm font-normal text-muted-foreground mr-1">{stat.unit}</span>
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">{stat.title}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Low Stock Alert Section */}
        {lowStockProducts.length > 0 && (
          <Card className="border-orange-200 bg-orange-50 dark:bg-orange-900/10 dark:border-orange-900/50">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-orange-700 dark:text-orange-400">
                  <AlertTriangle className="h-5 w-5" />
                  <CardTitle className="text-lg">تنبيهات المخزون المنخفض</CardTitle>
                </div>
                <Link to="/inventory">
                  <Button variant="ghost" size="sm" className="text-orange-700 hover:text-orange-800 hover:bg-orange-100 dark:text-orange-400 dark:hover:bg-orange-900/30 gap-1">
                    إدارة المخزون
                    <ArrowLeft className="h-4 w-4" />
                  </Button>
                </Link>
              </div>
              <CardDescription className="text-orange-600/80 dark:text-orange-400/80">
                يوجد {lowStockProducts.length} منتجات قاربت على النفاذ (أقل من 20 قطعة)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {lowStockProducts.slice(0, 6).map(product => (
                  <div key={product.id} className="flex items-center justify-between p-3 bg-white dark:bg-card rounded-lg border border-orange-100 dark:border-orange-900/30 shadow-sm">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center text-orange-600 dark:text-orange-400 font-bold text-xs">
                        {product.quantity}
                      </div>
                      <div>
                        <p className="font-medium text-sm text-foreground">{product.name}</p>
                        <p className="text-xs text-muted-foreground">سعر الشراء: {product.netPurchaseCost}</p>
                      </div>
                    </div>
                    <Link to="/purchases">
                      <Button size="sm" variant="outline" className="h-7 text-xs">
                        طلب
                      </Button>
                    </Link>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Charts */}
        <div className="grid gap-6 md:grid-cols-2">
          {/* Sales Chart */}
          <Card>
            <CardHeader>
              <CardTitle>المبيعات حسب المنتج</CardTitle>
              <CardDescription>توزيع المبيعات على المنتجات</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={salesByProduct} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis type="number" stroke="hsl(var(--muted-foreground))" />
                    <YAxis dataKey="name" type="category" width={100} stroke="hsl(var(--muted-foreground))" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                      formatter={(value: number) => [`${value.toLocaleString('ar-YE')} ر.ي.`, 'المبيعات']}
                    />
                    <Bar dataKey="value" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Category Distribution */}
          <Card>
            <CardHeader>
              <CardTitle>توزيع المخزون</CardTitle>
              <CardDescription>نسبة المنتجات حسب النوع</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={categoryData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={5}
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {categoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                      formatter={(value: number) => [`${value} وحدة`, 'الكمية']}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-center gap-6 mt-4">
                {categoryData.map((item, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                    <span className="text-sm text-muted-foreground">{item.name}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Sales */}
        <Card>
          <CardHeader>
            <CardTitle>آخر المبيعات</CardTitle>
            <CardDescription>أحدث عمليات البيع</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {sales.slice(0, 5).map((sale) => (
                <div key={sale.id} className="flex items-center justify-between p-4 bg-accent rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <ShoppingCart className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{sale.productName}</p>
                      <p className="text-sm text-muted-foreground">{sale.quantity} وحدة</p>
                    </div>
                  </div>
                  <div className="text-left">
                    <p className="font-bold text-foreground">{sale.totalPrice.toLocaleString('ar-YE')} ر.ي.</p>
                    <p className="text-sm text-primary">+{sale.profit.toLocaleString('ar-YE')} ربح</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default Dashboard;
