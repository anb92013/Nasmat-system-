import { useState, useRef } from 'react';
import { Layout } from '@/components/Layout';
import { useApp } from '@/context/AppContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Purchase, Product } from '@/types';
import { Plus, ShoppingBag, Truck, Package, FileText, Printer } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';
import { PurchaseInvoice } from '@/components/PurchaseInvoice';
import { useReactToPrint } from 'react-to-print';

const Purchases = () => {
  const { products, purchases, addPurchase, suppliers, addProduct } = useApp();
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isNewProductDialogOpen, setIsNewProductDialogOpen] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [selectedSupplierId, setSelectedSupplierId] = useState('none');
  const [selectedPurchase, setSelectedPurchase] = useState<Purchase | null>(null);
  const [isInvoiceOpen, setIsInvoiceOpen] = useState(false);
  const invoiceRef = useRef<HTMLDivElement>(null);

  // New Product Form State
  const [newProductFormData, setNewProductFormData] = useState({
    name: '',
    weightGrams: 0,
    costPerGram: 0,
    purchaseCost: 0,
    labelCost: 0,
    packagingBagCost: 0,
    wrapBagCost: 0,
    workerCost: 0,
    sellingPrice: 0,
    quantity: 0,
    category: 'henna',
  });
  const [customCategory, setCustomCategory] = useState('');

  const selectedProduct = products.find(p => p.id === selectedProductId);
  const selectedSupplier = suppliers.find(s => s.id === selectedSupplierId);

  const handlePrint = useReactToPrint({
    contentRef: invoiceRef,
  });

  const openInvoice = (purchase: Purchase) => {
    setSelectedPurchase(purchase);
    setIsInvoiceOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedProduct) {
      toast({ title: 'خطأ', description: 'يرجى اختيار منتج', variant: 'destructive' });
      return;
    }

    const totalCost = selectedProduct.netPurchaseCost * quantity;

    const newPurchase: Purchase = {
      id: crypto.randomUUID(),
      productId: selectedProduct.id,
      productName: selectedProduct.name,
      quantity,
      unitCost: selectedProduct.netPurchaseCost,
      totalCost,
      supplierId: selectedSupplierId !== 'none' ? selectedSupplierId : undefined,
      supplier: selectedSupplier?.name,
      date: new Date(),
    };

    addPurchase(newPurchase);
    toast({ title: 'تم الشراء', description: `تم تسجيل شراء ${quantity} وحدة من ${selectedProduct.name}` });
    
    setIsDialogOpen(false);
    setSelectedProductId('');
    setQuantity(1);
    setSelectedSupplierId('none');
  };

  const handleNewProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const netPurchaseCost = newProductFormData.purchaseCost + newProductFormData.labelCost + newProductFormData.packagingBagCost + newProductFormData.wrapBagCost + newProductFormData.workerCost;
    const extras5Percent = netPurchaseCost * 0.05;
    const sale5Percent = netPurchaseCost * 0.05;
    const profit35Percent = netPurchaseCost * 0.35;
    
    const finalCategory = newProductFormData.category === 'other' ? customCategory : newProductFormData.category;

    const newProduct: Product = {
      id: crypto.randomUUID(),
      ...newProductFormData,
      category: finalCategory,
      netPurchaseCost,
      extras5Percent,
      sale5Percent,
      profit35Percent,
      createdAt: new Date(),
    };

    addProduct(newProduct);
    toast({ title: 'تمت الإضافة', description: 'تم إضافة المنتج الجديد بنجاح' });
    setIsNewProductDialogOpen(false);
    // Select the newly created product automatically
    setSelectedProductId(newProduct.id);
  };

  const totalPurchasesAmount = purchases.reduce((sum, p) => sum + p.totalCost, 0);
  const totalQuantity = purchases.reduce((sum, p) => sum + p.quantity, 0);

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">إدارة المشتريات</h1>
            <p className="text-muted-foreground mt-1">تسجيل ومتابعة عمليات الشراء</p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                تسجيل شراء
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>تسجيل عملية شراء جديدة</DialogTitle>
                <DialogDescription>
                  أدخل تفاصيل عملية الشراء
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label>المنتج</Label>
                  <div className="flex gap-2">
                    <Select value={selectedProductId} onValueChange={setSelectedProductId}>
                      <SelectTrigger className="flex-1">
                        <SelectValue placeholder="اختر المنتج" />
                      </SelectTrigger>
                      <SelectContent>
                        {products.map((product) => (
                          <SelectItem key={product.id} value={product.id}>
                            {product.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button 
                      type="button" 
                      variant="outline" 
                      size="icon"
                      onClick={() => setIsNewProductDialogOpen(true)}
                      title="إضافة منتج جديد"
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>الكمية</Label>
                  <Input
                    type="number"
                    min={1}
                    value={quantity}
                    onChange={(e) => setQuantity(Number(e.target.value))}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label>المورد (اختياري)</Label>
                  <Select value={selectedSupplierId} onValueChange={setSelectedSupplierId}>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر المورد" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">بدون مورد</SelectItem>
                      {suppliers.map((supplier) => (
                        <SelectItem key={supplier.id} value={supplier.id}>
                          {supplier.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedProduct && (
                  <div className="p-4 bg-accent rounded-lg space-y-2">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">تكلفة الوحدة:</span>
                      <span className="font-medium">{selectedProduct.netPurchaseCost.toLocaleString('ar-YE')} ر.ي.</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">الإجمالي:</span>
                      <span className="font-bold text-lg">{(selectedProduct.netPurchaseCost * quantity).toLocaleString('ar-YE')} ر.ي.</span>
                    </div>
                  </div>
                )}

                <div className="flex justify-end gap-2 pt-4">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    إلغاء
                  </Button>
                  <Button type="submit" disabled={!selectedProductId}>
                    تأكيد الشراء
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* New Product Dialog */}
        <Dialog open={isNewProductDialogOpen} onOpenChange={setIsNewProductDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>إضافة منتج جديد</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleNewProductSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>اسم المنتج</Label>
                  <Input
                    value={newProductFormData.name}
                    onChange={(e) => setNewProductFormData({ ...newProductFormData, name: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>النوع</Label>
                  <Select
                    value={newProductFormData.category}
                    onValueChange={(value) => setNewProductFormData({ ...newProductFormData, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="henna">حناء</SelectItem>
                      <SelectItem value="sidr">سدر</SelectItem>
                      <SelectItem value="other">تصنيف آخر...</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {newProductFormData.category === 'other' && (
                <div className="space-y-2">
                  <Label>اسم التصنيف الجديد</Label>
                  <Input
                    value={customCategory}
                    onChange={(e) => setCustomCategory(e.target.value)}
                    required
                  />
                </div>
              )}

              {/* Simplified form for quick add */}
              <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>تكلفة الشراء</Label>
                    <Input
                      type="number"
                      value={newProductFormData.purchaseCost}
                      onChange={(e) => setNewProductFormData({ ...newProductFormData, purchaseCost: Number(e.target.value) })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>سعر البيع</Label>
                    <Input
                      type="number"
                      value={newProductFormData.sellingPrice}
                      onChange={(e) => setNewProductFormData({ ...newProductFormData, sellingPrice: Number(e.target.value) })}
                      required
                    />
                  </div>
              </div>

              <div className="space-y-2">
                <Label>الكمية الأولية</Label>
                <Input
                  type="number"
                  value={newProductFormData.quantity}
                  onChange={(e) => setNewProductFormData({ ...newProductFormData, quantity: Number(e.target.value) })}
                  required
                />
              </div>

              <Button type="submit" className="w-full">إضافة المنتج</Button>
            </form>
          </DialogContent>
        </Dialog>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-primary">
                  <ShoppingBag className="h-6 w-6 text-primary-foreground" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{totalPurchasesAmount.toLocaleString('ar-YE')}</p>
                  <p className="text-sm text-muted-foreground">إجمالي المشتريات (ر.ي.)</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-chart-2">
                  <Package className="h-6 w-6 text-primary-foreground" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{totalQuantity}</p>
                  <p className="text-sm text-muted-foreground">إجمالي الوحدات</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-chart-3">
                  <Truck className="h-6 w-6 text-primary-foreground" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{purchases.length}</p>
                  <p className="text-sm text-muted-foreground">عمليات الشراء</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Purchases Table */}
        <Card>
          <CardHeader>
            <CardTitle>سجل المشتريات</CardTitle>
            <CardDescription>جميع عمليات الشراء المسجلة</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>التاريخ</TableHead>
                    <TableHead>المنتج</TableHead>
                    <TableHead>الكمية</TableHead>
                    <TableHead>تكلفة الوحدة</TableHead>
                    <TableHead>الإجمالي</TableHead>
                    <TableHead>المورد</TableHead>
                    <TableHead>الفاتورة</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {purchases.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                        لا توجد مشتريات مسجلة بعد
                      </TableCell>
                    </TableRow>
                  ) : (
                    purchases.map((purchase) => (
                      <TableRow key={purchase.id}>
                        <TableCell>
                          {format(new Date(purchase.date), 'dd MMM yyyy', { locale: ar })}
                        </TableCell>
                        <TableCell className="font-medium">{purchase.productName}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{purchase.quantity}</Badge>
                        </TableCell>
                        <TableCell>{purchase.unitCost.toLocaleString('ar-YE')} ر.ي.</TableCell>
                        <TableCell className="font-bold">{purchase.totalCost.toLocaleString('ar-YE')} ر.ي.</TableCell>
                        <TableCell className="text-muted-foreground">
                          {purchase.supplier || '-'}
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => openInvoice(purchase)}
                            className="gap-1"
                          >
                            <FileText className="h-4 w-4" />
                            عرض
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Invoice Dialog */}
        <Dialog open={isInvoiceOpen} onOpenChange={setIsInvoiceOpen}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>فاتورة الشراء</DialogTitle>
              <DialogDescription>
                يمكنك طباعة الفاتورة أو حفظها
              </DialogDescription>
            </DialogHeader>
            {selectedPurchase && (
              <>
                <PurchaseInvoice ref={invoiceRef} purchase={selectedPurchase} />
                <div className="flex justify-end gap-2 mt-4">
                  <Button variant="outline" onClick={() => setIsInvoiceOpen(false)}>
                    إغلاق
                  </Button>
                  <Button onClick={() => handlePrint()} className="gap-2">
                    <Printer className="h-4 w-4" />
                    طباعة
                  </Button>
                </div>
              </>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
};

export default Purchases;
