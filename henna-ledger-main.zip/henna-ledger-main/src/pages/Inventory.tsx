import { useState } from 'react';
import { Layout } from '@/components/Layout';
import { useApp } from '@/context/AppContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Product } from '@/types';
import { Plus, Edit, Trash2, Search, Package, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

const Inventory = () => {
  const { products, addProduct, updateProduct, deleteProduct } = useApp();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [customCategory, setCustomCategory] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    weightGrams: 0,
    costPerGram: 0,
    purchaseCost: 0,
    labelCost: 0,
    packagingBagCost: 0,
    wrapBagCost: 0,
    workerCost: 0,
    sellingPrice: 0,
    quantity: 0,
    category: 'henna',
  });

  // Get unique categories from products for filter
  const categories = Array.from(new Set(products.map(p => p.category)));

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || product.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const calculateCosts = (data: typeof formData) => {
    const netPurchaseCost = data.purchaseCost + data.labelCost + data.packagingBagCost + data.wrapBagCost + data.workerCost;
    const extras5Percent = netPurchaseCost * 0.05;
    const sale5Percent = netPurchaseCost * 0.05;
    const profit35Percent = netPurchaseCost * 0.35;
    return { netPurchaseCost, extras5Percent, sale5Percent, profit35Percent };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const costs = calculateCosts(formData);
      
      const finalCategory = formData.category === 'other' ? customCategory : formData.category;

      if (formData.category === 'other' && !customCategory) {
        toast({ title: 'خطأ', description: 'يرجى إدخال اسم التصنيف الجديد', variant: 'destructive' });
        setIsSubmitting(false);
        return;
      }

      const productData = {
        ...formData,
        category: finalCategory,
        ...costs,
      };
      
      if (editingProduct) {
        await updateProduct(editingProduct.id, productData);
        toast({ title: 'تم التحديث', description: 'تم تحديث المنتج بنجاح' });
      } else {
        const newProduct: Product = {
          id: crypto.randomUUID(), // Use proper UUID
          ...productData,
          createdAt: new Date(),
        };
        await addProduct(newProduct);
        toast({ title: 'تمت الإضافة', description: 'تم إضافة المنتج بنجاح' });
      }
      
      resetForm();
    } catch (error) {
      // Error handled in context
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      weightGrams: 0,
      costPerGram: 0,
      purchaseCost: 0,
      labelCost: 0,
      packagingBagCost: 0,
      wrapBagCost: 0,
      workerCost: 0,
      sellingPrice: 0,
      quantity: 0,
      category: 'henna',
    });
    setCustomCategory('');
    setEditingProduct(null);
    setIsAddDialogOpen(false);
  };

  const handleEdit = (product: Product) => {
    setFormData({
      name: product.name,
      weightGrams: product.weightGrams,
      costPerGram: product.costPerGram,
      purchaseCost: product.purchaseCost,
      labelCost: product.labelCost,
      packagingBagCost: product.packagingBagCost,
      wrapBagCost: product.wrapBagCost,
      workerCost: product.workerCost,
      sellingPrice: product.sellingPrice,
      quantity: product.quantity,
      category: product.category,
    });
    setEditingProduct(product);
    setIsAddDialogOpen(true);
  };

  const handleDelete = async (id: string) => {
    if(confirm('هل أنت متأكد من حذف هذا المنتج؟')) {
      await deleteProduct(id);
      toast({ title: 'تم الحذف', description: 'تم حذف المنتج بنجاح' });
    }
  };

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">إدارة المخزون</h1>
            <p className="text-muted-foreground mt-1">إدارة منتجات الحناء والسدر وغيرها</p>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2" onClick={resetForm}>
                <Plus className="h-4 w-4" />
                إضافة منتج
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingProduct ? 'تعديل المنتج' : 'إضافة منتج جديد'}</DialogTitle>
                <DialogDescription>
                  أدخل تفاصيل المنتج وتكاليفه
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>اسم المنتج</Label>
                    <Input
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="مثال: حناء 100 جرام"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>النوع</Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => setFormData({ ...formData, category: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="henna">حناء</SelectItem>
                        <SelectItem value="sidr">سدر</SelectItem>
                        <SelectItem value="other">تصنيف آخر...</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {formData.category === 'other' && (
                  <div className="space-y-2">
                    <Label>اسم التصنيف الجديد</Label>
                    <Input
                      value={customCategory}
                      onChange={(e) => setCustomCategory(e.target.value)}
                      placeholder="أدخل اسم التصنيف"
                      required
                    />
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>الوزن (جرام)</Label>
                    <Input
                      type="number"
                      value={formData.weightGrams}
                      onChange={(e) => setFormData({ ...formData, weightGrams: Number(e.target.value) })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>تكلفة الجرام</Label>
                    <Input
                      type="number"
                      step="0.1"
                      value={formData.costPerGram}
                      onChange={(e) => setFormData({ ...formData, costPerGram: Number(e.target.value) })}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>تكلفة الشراء</Label>
                    <Input
                      type="number"
                      value={formData.purchaseCost}
                      onChange={(e) => setFormData({ ...formData, purchaseCost: Number(e.target.value) })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>تكلفة الملصق</Label>
                    <Input
                      type="number"
                      value={formData.labelCost}
                      onChange={(e) => setFormData({ ...formData, labelCost: Number(e.target.value) })}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>تكلفة كيس التعبئة</Label>
                    <Input
                      type="number"
                      value={formData.packagingBagCost}
                      onChange={(e) => setFormData({ ...formData, packagingBagCost: Number(e.target.value) })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>تكلفة كيس التغليف</Label>
                    <Input
                      type="number"
                      value={formData.wrapBagCost}
                      onChange={(e) => setFormData({ ...formData, wrapBagCost: Number(e.target.value) })}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>حساب العامل</Label>
                    <Input
                      type="number"
                      value={formData.workerCost}
                      onChange={(e) => setFormData({ ...formData, workerCost: Number(e.target.value) })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>سعر البيع</Label>
                    <Input
                      type="number"
                      value={formData.sellingPrice}
                      onChange={(e) => setFormData({ ...formData, sellingPrice: Number(e.target.value) })}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>الكمية المتوفرة</Label>
                  <Input
                    type="number"
                    value={formData.quantity}
                    onChange={(e) => setFormData({ ...formData, quantity: Number(e.target.value) })}
                    required
                  />
                </div>

                <div className="flex justify-end gap-2 pt-4">
                  <Button type="button" variant="outline" onClick={resetForm} disabled={isSubmitting}>
                    إلغاء
                  </Button>
                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? 'جاري الحفظ...' : (editingProduct ? 'تحديث' : 'إضافة')}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="البحث عن منتج..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10"
                />
              </div>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-full sm:w-40">
                  <SelectValue placeholder="النوع" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">الكل</SelectItem>
                  <SelectItem value="henna">حناء</SelectItem>
                  <SelectItem value="sidr">سدر</SelectItem>
                  {categories.filter(c => c !== 'henna' && c !== 'sidr').map(c => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Products Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              المنتجات ({filteredProducts.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>المنتج</TableHead>
                    <TableHead>النوع</TableHead>
                    <TableHead>الوزن</TableHead>
                    <TableHead>تكلفة الشراء</TableHead>
                    <TableHead>سعر البيع</TableHead>
                    <TableHead>الربح</TableHead>
                    <TableHead>الكمية</TableHead>
                    <TableHead>إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredProducts.map((product) => {
                    const isLowStock = product.quantity <= 20;
                    return (
                      <TableRow key={product.id} className={cn(isLowStock && "bg-orange-50 dark:bg-orange-900/10 hover:bg-orange-100 dark:hover:bg-orange-900/20")}>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            {product.name}
                            {isLowStock && (
                              <AlertCircle className="h-4 w-4 text-orange-500" />
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={product.category === 'henna' ? 'default' : 'secondary'}>
                            {product.category === 'henna' ? 'حناء' : product.category === 'sidr' ? 'سدر' : product.category}
                          </Badge>
                        </TableCell>
                        <TableCell>{product.weightGrams} جرام</TableCell>
                        <TableCell>{product.netPurchaseCost.toLocaleString('ar-YE')} ر.ي.</TableCell>
                        <TableCell>{product.sellingPrice.toLocaleString('ar-YE')} ر.ي.</TableCell>
                        <TableCell className="text-primary">
                          {product.profit35Percent.toLocaleString('ar-YE')} ر.ي.
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant={isLowStock ? 'destructive' : 'outline'}
                            className={cn(isLowStock && "bg-orange-500 hover:bg-orange-600 border-orange-500")}
                          >
                            {product.quantity}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleEdit(product)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDelete(product.id)}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default Inventory;
