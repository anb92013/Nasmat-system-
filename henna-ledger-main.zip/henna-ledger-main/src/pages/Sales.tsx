import { useState, useRef } from 'react';
import { Layout } from '@/components/Layout';
import { useApp } from '@/context/AppContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Sale } from '@/types';
import { Plus, ShoppingCart, Calendar, TrendingUp, FileText, Printer } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';
import { SalesInvoice } from '@/components/SalesInvoice';
import { useReactToPrint } from 'react-to-print';

const Sales = () => {
  const { products, sales, addSale } = useApp();
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [selectedSale, setSelectedSale] = useState<Sale | null>(null);
  const [isInvoiceOpen, setIsInvoiceOpen] = useState(false);
  const invoiceRef = useRef<HTMLDivElement>(null);

  const selectedProduct = products.find(p => p.id === selectedProductId);

  const handlePrint = useReactToPrint({
    contentRef: invoiceRef,
  });

  const openInvoice = (sale: Sale) => {
    setSelectedSale(sale);
    setIsInvoiceOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedProduct) {
      toast({ title: 'خطأ', description: 'يرجى اختيار منتج', variant: 'destructive' });
      return;
    }

    if (quantity > selectedProduct.quantity) {
      toast({ title: 'خطأ', description: 'الكمية المطلوبة أكبر من المتوفرة', variant: 'destructive' });
      return;
    }

    const totalPrice = selectedProduct.sellingPrice * quantity;
    const profit = selectedProduct.profit35Percent * quantity;

    const newSale: Sale = {
      id: crypto.randomUUID(),
      productId: selectedProduct.id,
      productName: selectedProduct.name,
      quantity,
      unitPrice: selectedProduct.sellingPrice,
      totalPrice,
      profit,
      date: new Date(),
    };

    addSale(newSale);
    toast({ title: 'تم البيع', description: `تم تسجيل بيع ${quantity} وحدة من ${selectedProduct.name}` });
    
    setIsDialogOpen(false);
    setSelectedProductId('');
    setQuantity(1);
  };

  const totalSalesAmount = sales.reduce((sum, s) => sum + s.totalPrice, 0);
  const totalProfit = sales.reduce((sum, s) => sum + s.profit, 0);
  const todaySales = sales.filter(s => {
    const today = new Date();
    const saleDate = new Date(s.date);
    return saleDate.toDateString() === today.toDateString();
  });

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">إدارة المبيعات</h1>
            <p className="text-muted-foreground mt-1">تسجيل ومتابعة عمليات البيع</p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                تسجيل بيع
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>تسجيل عملية بيع جديدة</DialogTitle>
                <DialogDescription>
                  اختر المنتج والكمية المباعة
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label>المنتج</Label>
                  <Select value={selectedProductId} onValueChange={setSelectedProductId}>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر المنتج" />
                    </SelectTrigger>
                    <SelectContent>
                      {products.filter(p => p.quantity > 0).map((product) => (
                        <SelectItem key={product.id} value={product.id}>
                          {product.name} (متوفر: {product.quantity})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>الكمية</Label>
                  <Input
                    type="number"
                    min={1}
                    max={selectedProduct?.quantity || 1}
                    value={quantity}
                    onChange={(e) => setQuantity(Number(e.target.value))}
                    required
                  />
                </div>

                {selectedProduct && (
                  <div className="p-4 bg-accent rounded-lg space-y-2">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">سعر الوحدة:</span>
                      <span className="font-medium">{selectedProduct.sellingPrice.toLocaleString('ar-YE')} ر.ي.</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">الإجمالي:</span>
                      <span className="font-bold text-lg">{(selectedProduct.sellingPrice * quantity).toLocaleString('ar-YE')} ر.ي.</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">الربح المتوقع:</span>
                      <span className="font-medium text-primary">{(selectedProduct.profit35Percent * quantity).toLocaleString('ar-YE')} ر.ي.</span>
                    </div>
                  </div>
                )}

                <div className="flex justify-end gap-2 pt-4">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    إلغاء
                  </Button>
                  <Button type="submit" disabled={!selectedProductId}>
                    تأكيد البيع
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-primary">
                  <ShoppingCart className="h-6 w-6 text-primary-foreground" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{totalSalesAmount.toLocaleString('ar-YE')}</p>
                  <p className="text-sm text-muted-foreground">إجمالي المبيعات (ر.ي.)</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-chart-2">
                  <TrendingUp className="h-6 w-6 text-primary-foreground" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{totalProfit.toLocaleString('ar-YE')}</p>
                  <p className="text-sm text-muted-foreground">إجمالي الأرباح (ر.ي.)</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-chart-3">
                  <Calendar className="h-6 w-6 text-primary-foreground" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{todaySales.length}</p>
                  <p className="text-sm text-muted-foreground">مبيعات اليوم</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sales Table */}
        <Card>
          <CardHeader>
            <CardTitle>سجل المبيعات</CardTitle>
            <CardDescription>جميع عمليات البيع المسجلة</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>التاريخ</TableHead>
                    <TableHead>المنتج</TableHead>
                    <TableHead>الكمية</TableHead>
                    <TableHead>سعر الوحدة</TableHead>
                    <TableHead>الإجمالي</TableHead>
                    <TableHead>الربح</TableHead>
                    <TableHead>الفاتورة</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sales.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                        لا توجد مبيعات مسجلة بعد
                      </TableCell>
                    </TableRow>
                  ) : (
                    sales.map((sale) => (
                      <TableRow key={sale.id}>
                        <TableCell>
                          {format(new Date(sale.date), 'dd MMM yyyy', { locale: ar })}
                        </TableCell>
                        <TableCell className="font-medium">{sale.productName}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{sale.quantity}</Badge>
                        </TableCell>
                        <TableCell>{sale.unitPrice.toLocaleString('ar-YE')} ر.ي.</TableCell>
                        <TableCell className="font-bold">{sale.totalPrice.toLocaleString('ar-YE')} ر.ي.</TableCell>
                        <TableCell className="text-primary font-medium">
                          +{sale.profit.toLocaleString('ar-YE')} ر.ي.
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => openInvoice(sale)}
                            className="gap-1"
                          >
                            <FileText className="h-4 w-4" />
                            عرض
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Invoice Dialog */}
        <Dialog open={isInvoiceOpen} onOpenChange={setIsInvoiceOpen}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>فاتورة البيع</DialogTitle>
              <DialogDescription>
                يمكنك طباعة الفاتورة أو حفظها
              </DialogDescription>
            </DialogHeader>
            {selectedSale && (
              <>
                <SalesInvoice ref={invoiceRef} sale={selectedSale} />
                <div className="flex justify-end gap-2 mt-4">
                  <Button variant="outline" onClick={() => setIsInvoiceOpen(false)}>
                    إغلاق
                  </Button>
                  <Button onClick={() => handlePrint()} className="gap-2">
                    <Printer className="h-4 w-4" />
                    طباعة
                  </Button>
                </div>
              </>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
};

export default Sales;
