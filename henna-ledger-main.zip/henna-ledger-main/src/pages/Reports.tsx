import { useState, useMemo } from 'react';
import { Layout } from '@/components/Layout';
import { useApp } from '@/context/AppContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Calendar, FileText, Download, TrendingUp, TrendingDown } from 'lucide-react';
import { format, startOfDay, startOfMonth, endOfMonth, eachDayOfInterval, subDays, isWithinInterval } from 'date-fns';
import { ar } from 'date-fns/locale';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const Reports = () => {
  const { sales, purchases } = useApp();
  const [reportType, setReportType] = useState<'daily' | 'monthly'>('daily');

  const dailyReports = useMemo(() => {
    const last30Days = eachDayOfInterval({
      start: subDays(new Date(), 29),
      end: new Date(),
    });

    return last30Days.map(day => {
      const dayStart = startOfDay(day);
      const dayEnd = new Date(dayStart);
      dayEnd.setHours(23, 59, 59, 999);

      const daySales = sales.filter(s => {
        const saleDate = new Date(s.date);
        return isWithinInterval(saleDate, { start: dayStart, end: dayEnd });
      });

      const dayPurchases = purchases.filter(p => {
        const purchaseDate = new Date(p.date);
        return isWithinInterval(purchaseDate, { start: dayStart, end: dayEnd });
      });

      const totalSales = daySales.reduce((sum, s) => sum + s.totalPrice, 0);
      const totalPurchases = dayPurchases.reduce((sum, p) => sum + p.totalCost, 0);
      const totalProfit = daySales.reduce((sum, s) => sum + s.profit, 0);

      return {
        date: day,
        dateFormatted: format(day, 'dd MMM', { locale: ar }),
        totalSales,
        totalPurchases,
        totalProfit,
        salesCount: daySales.length,
        purchasesCount: dayPurchases.length,
      };
    });
  }, [sales, purchases]);

  const monthlyReports = useMemo(() => {
    const months: { month: Date; name: string }[] = [];
    for (let i = 5; i >= 0; i--) {
      const date = new Date();
      date.setMonth(date.getMonth() - i);
      months.push({
        month: date,
        name: format(date, 'MMMM yyyy', { locale: ar }),
      });
    }

    return months.map(({ month, name }) => {
      const monthStart = startOfMonth(month);
      const monthEnd = endOfMonth(month);

      const monthSales = sales.filter(s => {
        const saleDate = new Date(s.date);
        return isWithinInterval(saleDate, { start: monthStart, end: monthEnd });
      });

      const monthPurchases = purchases.filter(p => {
        const purchaseDate = new Date(p.date);
        return isWithinInterval(purchaseDate, { start: monthStart, end: monthEnd });
      });

      const totalSales = monthSales.reduce((sum, s) => sum + s.totalPrice, 0);
      const totalPurchases = monthPurchases.reduce((sum, p) => sum + p.totalCost, 0);
      const totalProfit = monthSales.reduce((sum, s) => sum + s.profit, 0);

      return {
        month: name,
        totalSales,
        totalPurchases,
        totalProfit,
        salesCount: monthSales.length,
        purchasesCount: monthPurchases.length,
      };
    });
  }, [sales, purchases]);

  const chartData = reportType === 'daily' 
    ? dailyReports.slice(-14).map(r => ({
        name: r.dateFormatted,
        sales: r.totalSales,
        profit: r.totalProfit,
      }))
    : monthlyReports.map(r => ({
        name: r.month,
        sales: r.totalSales,
        profit: r.totalProfit,
      }));

  const todayReport = dailyReports[dailyReports.length - 1];

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">التقارير</h1>
            <p className="text-muted-foreground mt-1">تقارير يومية وشهرية</p>
          </div>
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            تصدير التقرير
          </Button>
        </div>

        {/* Today's Summary */}
        <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              ملخص اليوم - {format(new Date(), 'EEEE dd MMMM yyyy', { locale: ar })}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-4">
              <div className="p-4 bg-card rounded-lg">
                <p className="text-sm text-muted-foreground">المبيعات</p>
                <p className="text-2xl font-bold">{todayReport.totalSales.toLocaleString('ar-YE')} ر.ي.</p>
                <p className="text-xs text-muted-foreground mt-1">{todayReport.salesCount} عملية</p>
              </div>
              <div className="p-4 bg-card rounded-lg">
                <p className="text-sm text-muted-foreground">المشتريات</p>
                <p className="text-2xl font-bold">{todayReport.totalPurchases.toLocaleString('ar-YE')} ر.ي.</p>
                <p className="text-xs text-muted-foreground mt-1">{todayReport.purchasesCount} عملية</p>
              </div>
              <div className="p-4 bg-card rounded-lg">
                <p className="text-sm text-muted-foreground">صافي الربح</p>
                <p className="text-2xl font-bold text-primary">{todayReport.totalProfit.toLocaleString('ar-YE')} ر.ي.</p>
              </div>
              <div className="p-4 bg-card rounded-lg">
                <p className="text-sm text-muted-foreground">الحالة</p>
                <div className="flex items-center gap-2 mt-1">
                  {todayReport.totalProfit > 0 ? (
                    <>
                      <TrendingUp className="h-5 w-5 text-primary" />
                      <span className="text-lg font-medium text-primary">ربح</span>
                    </>
                  ) : (
                    <>
                      <TrendingDown className="h-5 w-5 text-destructive" />
                      <span className="text-lg font-medium text-destructive">خسارة</span>
                    </>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Chart */}
        <Card>
          <CardHeader>
            <CardTitle>تحليل المبيعات والأرباح</CardTitle>
            <CardDescription>
              {reportType === 'daily' ? 'آخر 14 يوم' : 'آخر 6 أشهر'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={reportType} onValueChange={(v) => setReportType(v as 'daily' | 'monthly')} className="mb-4">
              <TabsList>
                <TabsTrigger value="daily">يومي</TabsTrigger>
                <TabsTrigger value="monthly">شهري</TabsTrigger>
              </TabsList>
            </Tabs>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" />
                  <YAxis stroke="hsl(var(--muted-foreground))" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                    formatter={(value: number) => `${value.toLocaleString('ar-YE')} ر.ي.`}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="sales" 
                    name="المبيعات" 
                    stroke="hsl(var(--chart-1))" 
                    fill="hsl(var(--chart-1))" 
                    fillOpacity={0.3}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="profit" 
                    name="الربح" 
                    stroke="hsl(var(--chart-2))" 
                    fill="hsl(var(--chart-2))" 
                    fillOpacity={0.3}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Reports Tables */}
        <Tabs defaultValue="daily" className="space-y-4">
          <TabsList>
            <TabsTrigger value="daily">التقرير اليومي</TabsTrigger>
            <TabsTrigger value="monthly">التقرير الشهري</TabsTrigger>
          </TabsList>

          <TabsContent value="daily">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  التقارير اليومية
                </CardTitle>
                <CardDescription>آخر 30 يوم</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>التاريخ</TableHead>
                        <TableHead>المبيعات</TableHead>
                        <TableHead>عدد العمليات</TableHead>
                        <TableHead>المشتريات</TableHead>
                        <TableHead>صافي الربح</TableHead>
                        <TableHead>الحالة</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {dailyReports.slice().reverse().slice(0, 15).map((report, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">
                            {format(report.date, 'EEEE dd/MM', { locale: ar })}
                          </TableCell>
                          <TableCell>{report.totalSales.toLocaleString('ar-YE')} ر.ي.</TableCell>
                          <TableCell>
                            <Badge variant="outline">{report.salesCount}</Badge>
                          </TableCell>
                          <TableCell>{report.totalPurchases.toLocaleString('ar-YE')} ر.ي.</TableCell>
                          <TableCell className={report.totalProfit > 0 ? 'text-primary font-bold' : 'text-destructive font-bold'}>
                            {report.totalProfit.toLocaleString('ar-YE')} ر.ي.
                          </TableCell>
                          <TableCell>
                            {report.totalSales > 0 || report.totalPurchases > 0 ? (
                              <Badge variant={report.totalProfit > 0 ? 'default' : 'destructive'}>
                                {report.totalProfit > 0 ? 'ربح' : 'خسارة'}
                              </Badge>
                            ) : (
                              <Badge variant="secondary">لا يوجد</Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="monthly">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  التقارير الشهرية
                </CardTitle>
                <CardDescription>آخر 6 أشهر</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>الشهر</TableHead>
                        <TableHead>إجمالي المبيعات</TableHead>
                        <TableHead>عدد العمليات</TableHead>
                        <TableHead>إجمالي المشتريات</TableHead>
                        <TableHead>صافي الربح</TableHead>
                        <TableHead>الحالة</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {monthlyReports.slice().reverse().map((report, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{report.month}</TableCell>
                          <TableCell>{report.totalSales.toLocaleString('ar-YE')} ر.ي.</TableCell>
                          <TableCell>
                            <Badge variant="outline">{report.salesCount}</Badge>
                          </TableCell>
                          <TableCell>{report.totalPurchases.toLocaleString('ar-YE')} ر.ي.</TableCell>
                          <TableCell className={report.totalProfit > 0 ? 'text-primary font-bold' : 'text-destructive font-bold'}>
                            {report.totalProfit.toLocaleString('ar-YE')} ر.ي.
                          </TableCell>
                          <TableCell>
                            {report.totalSales > 0 || report.totalPurchases > 0 ? (
                              <Badge variant={report.totalProfit > 0 ? 'default' : 'destructive'}>
                                {report.totalProfit > 0 ? 'ربح' : 'خسارة'}
                              </Badge>
                            ) : (
                              <Badge variant="secondary">لا يوجد</Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default Reports;
