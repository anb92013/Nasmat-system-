import { useMemo, useRef, useState, useEffect } from 'react';
import { Layout } from '@/components/Layout';
import { useApp } from '@/context/AppContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { TrendingUp, DollarSign, Percent, Calculator, Wallet, Printer, ArrowRightLeft, Target } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, Cell } from 'recharts';
import { useReactToPrint } from 'react-to-print';
import { ProfitReport } from '@/components/ProfitReport';
import { Dialog, DialogContent, DialogTrigger, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';

const Profits = () => {
  const { products, sales, purchases, expenses } = useApp();
  const reportRef = useRef<HTMLDivElement>(null);
  const [isReportOpen, setIsReportOpen] = useState(false);

  // Calculator State
  const [calcMode, setCalcMode] = useState<'price' | 'margin'>('price');
  const [calcCost, setCalcCost] = useState<number>(0);
  const [calcTargetMargin, setCalcTargetMargin] = useState<number>(35);
  const [calcSellingPrice, setCalcSellingPrice] = useState<number>(0);
  
  // Calculator Results
  const [calcResultPrice, setCalcResultPrice] = useState<number>(0);
  const [calcResultMargin, setCalcResultMargin] = useState<number>(0);
  const [calcResultProfit, setCalcResultProfit] = useState<number>(0);

  useEffect(() => {
    if (calcMode === 'price') {
      // Calculate Price based on Cost + Margin %
      // Formula: Price = Cost + (Cost * Margin%)
      const profitAmount = calcCost * (calcTargetMargin / 100);
      const price = calcCost + profitAmount;
      setCalcResultPrice(price);
      setCalcResultProfit(profitAmount);
    } else {
      // Calculate Margin % based on Cost + Selling Price
      // Formula: Margin % = ((Price - Cost) / Cost) * 100
      if (calcCost > 0 && calcSellingPrice > 0) {
        const profit = calcSellingPrice - calcCost;
        const margin = (profit / calcCost) * 100;
        setCalcResultMargin(margin);
        setCalcResultProfit(profit);
      } else {
        setCalcResultMargin(0);
        setCalcResultProfit(0);
      }
    }
  }, [calcMode, calcCost, calcTargetMargin, calcSellingPrice]);

  const handlePrint = useReactToPrint({
    contentRef: reportRef,
  });

  const profitAnalysis = useMemo(() => {
    const totalSales = sales.reduce((sum, s) => sum + s.totalPrice, 0);
    const totalPurchases = purchases.reduce((sum, p) => sum + p.totalCost, 0);
    const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
    
    const grossProfit = sales.reduce((sum, s) => sum + s.profit, 0);
    const netProfit = grossProfit - totalExpenses;
    
    const profitMargin = totalSales > 0 ? (netProfit / totalSales) * 100 : 0;

    // Profit by product
    const profitByProduct = products.map(product => {
      const productSales = sales.filter(s => s.productId === product.id);
      const productProfit = productSales.reduce((sum, s) => sum + s.profit, 0);
      const productRevenue = productSales.reduce((sum, s) => sum + s.totalPrice, 0);
      const unitsSold = productSales.reduce((sum, s) => sum + s.quantity, 0);
      
      // Calculate dynamic margin metrics
      const actualMarginPercent = product.sellingPrice > 0 
        ? ((product.sellingPrice - product.netPurchaseCost) / product.sellingPrice) * 100 
        : 0;
        
      const roiPercent = product.netPurchaseCost > 0
        ? ((product.sellingPrice - product.netPurchaseCost) / product.netPurchaseCost) * 100
        : 0;

      return {
        id: product.id,
        name: product.name,
        category: product.category,
        unitsSold,
        revenue: productRevenue,
        profit: productProfit,
        profitPerUnit: product.sellingPrice - product.netPurchaseCost,
        costPerUnit: product.netPurchaseCost,
        sellingPrice: product.sellingPrice,
        marginPercent: actualMarginPercent,
        roiPercent: roiPercent,
      };
    }).filter(p => p.unitsSold > 0 || p.profit > 0).sort((a, b) => b.profit - a.profit);

    // Cost breakdown
    const costBreakdown = products.map(product => ({
      name: product.name,
      purchaseCost: product.purchaseCost,
      labelCost: product.labelCost,
      packagingCost: product.packagingBagCost + product.wrapBagCost,
      workerCost: product.workerCost,
      extras: product.extras5Percent,
    }));

    return {
      totalSales,
      totalPurchases,
      totalExpenses,
      grossProfit,
      netProfit,
      profitMargin,
      profitByProduct,
      costBreakdown,
    };
  }, [products, sales, purchases, expenses]);

  const profitChartData = profitAnalysis.profitByProduct.slice(0, 10).map(p => ({
    name: p.name.replace('حناء ', '').replace('سدر ', ''),
    profit: p.profit,
    revenue: p.revenue,
  }));

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">تحليل الأرباح والتسعير</h1>
            <p className="text-muted-foreground mt-1">أدوات متقدمة للتحكم في الهوامش وتحليل الأداء المالي</p>
          </div>
          <Dialog open={isReportOpen} onOpenChange={setIsReportOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Printer className="h-4 w-4" />
                طباعة التقرير
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>تقرير الأرباح</DialogTitle>
                <DialogDescription>
                  معاينة تقرير الأرباح والتحليل المالي قبل الطباعة
                </DialogDescription>
              </DialogHeader>
              <ProfitReport 
                ref={reportRef}
                data={profitAnalysis.profitByProduct}
                totalRevenue={profitAnalysis.totalSales}
                totalProfit={profitAnalysis.netProfit}
                date={new Date()}
              />
              <div className="flex justify-end gap-2 mt-4">
                <Button onClick={() => handlePrint()}>تأكيد الطباعة</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Stats Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Stats Grid */}
            <div className="grid gap-4 sm:grid-cols-2">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-lg bg-primary">
                      <DollarSign className="h-6 w-6 text-primary-foreground" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold">{profitAnalysis.totalSales.toLocaleString('ar-YE')}</p>
                      <p className="text-sm text-muted-foreground">إجمالي الإيرادات</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-lg bg-chart-2">
                      <TrendingUp className="h-6 w-6 text-primary-foreground" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-primary">{profitAnalysis.netProfit.toLocaleString('ar-YE')}</p>
                      <p className="text-sm text-muted-foreground">صافي الربح الحقيقي</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-lg bg-destructive/10">
                      <Wallet className="h-6 w-6 text-destructive" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold">{profitAnalysis.totalExpenses.toLocaleString('ar-YE')}</p>
                      <p className="text-sm text-muted-foreground">المصروفات التشغيلية</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-lg bg-chart-4">
                      <Percent className="h-6 w-6 text-primary-foreground" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold">{profitAnalysis.profitMargin.toFixed(1)}%</p>
                      <p className="text-sm text-muted-foreground">هامش الربح الصافي</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Profit Chart */}
            <Card>
              <CardHeader>
                <CardTitle>الأرباح حسب المنتج</CardTitle>
                <CardDescription>أعلى 10 منتجات تحقيقاً للأرباح</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={profitChartData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" />
                      <YAxis stroke="hsl(var(--muted-foreground))" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'hsl(var(--card))',
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px',
                        }}
                        formatter={(value: number) => `${value.toLocaleString('ar-YE')} ر.ي.`}
                      />
                      <Bar dataKey="revenue" name="الإيرادات" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="profit" name="الربح الإجمالي" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Calculator Column */}
          <div className="space-y-6">
            <Card className="h-full border-primary/20 shadow-md">
              <CardHeader className="bg-primary/5 pb-4">
                <div className="flex items-center gap-2 text-primary">
                  <Calculator className="h-5 w-5" />
                  <CardTitle>حاسبة تسعير المنتج</CardTitle>
                </div>
                <CardDescription>أداة لمساعدتك في تحديد السعر المناسب</CardDescription>
              </CardHeader>
              <CardContent className="pt-6 space-y-6">
                <Tabs value={calcMode} onValueChange={(v) => setCalcMode(v as 'price' | 'margin')} className="w-full">
                  <TabsList className="w-full grid grid-cols-2">
                    <TabsTrigger value="price">حساب السعر</TabsTrigger>
                    <TabsTrigger value="margin">حساب النسبة</TabsTrigger>
                  </TabsList>
                  
                  <div className="mt-6 space-y-4">
                    <div className="space-y-2">
                      <Label>التكلفة الكلية (ر.ي.)</Label>
                      <Input 
                        type="number" 
                        value={calcCost} 
                        onChange={(e) => setCalcCost(Number(e.target.value))}
                        placeholder="أدخل تكلفة المنتج"
                      />
                    </div>

                    {calcMode === 'price' ? (
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <Label>نسبة الربح المستهدفة</Label>
                            <span className="text-sm font-bold text-primary">{calcTargetMargin}%</span>
                          </div>
                          <Slider 
                            value={[calcTargetMargin]} 
                            onValueChange={(v) => setCalcTargetMargin(v[0])} 
                            max={100} 
                            step={1}
                            className="py-2"
                          />
                        </div>
                        
                        <div className="p-4 bg-accent rounded-lg space-y-3 border border-border">
                          <div className="flex justify-between items-center">
                            <span className="text-muted-foreground">سعر البيع المقترح:</span>
                            <span className="text-xl font-bold text-primary">{calcResultPrice.toLocaleString('ar-YE')} ر.ي.</span>
                          </div>
                          <div className="flex justify-between items-center text-sm">
                            <span className="text-muted-foreground">صافي الربح:</span>
                            <span className="font-medium text-green-600">+{calcResultProfit.toLocaleString('ar-YE')} ر.ي.</span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                         <div className="space-y-2">
                          <Label>سعر البيع المقترح (ر.ي.)</Label>
                          <Input 
                            type="number" 
                            value={calcSellingPrice} 
                            onChange={(e) => setCalcSellingPrice(Number(e.target.value))}
                            placeholder="أدخل سعر البيع"
                          />
                        </div>

                        <div className="p-4 bg-accent rounded-lg space-y-3 border border-border">
                          <div className="flex justify-between items-center">
                            <span className="text-muted-foreground">نسبة الربح (ROI):</span>
                            <span className={`text-xl font-bold ${calcResultMargin >= 30 ? 'text-green-600' : calcResultMargin >= 15 ? 'text-yellow-600' : 'text-red-600'}`}>
                              {calcResultMargin.toFixed(1)}%
                            </span>
                          </div>
                          <div className="flex justify-between items-center text-sm">
                            <span className="text-muted-foreground">صافي الربح:</span>
                            <span className="font-medium text-green-600">+{calcResultProfit.toLocaleString('ar-YE')} ر.ي.</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </Tabs>

                <div className="text-xs text-muted-foreground bg-muted p-3 rounded border">
                  <p className="font-semibold mb-1">نصيحة:</p>
                  <p>حاول الحفاظ على نسبة ربح أعلى من 30% لتغطية المصروفات التشغيلية والمخاطر.</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Profit Details Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              تحليل هوامش الربح التفصيلي
            </CardTitle>
            <CardDescription>مقارنة الأداء المالي لكل منتج</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>المنتج</TableHead>
                    <TableHead>التكلفة</TableHead>
                    <TableHead>سعر البيع</TableHead>
                    <TableHead>ربح الوحدة</TableHead>
                    <TableHead>هامش الربح %</TableHead>
                    <TableHead>العائد (ROI)</TableHead>
                    <TableHead>إجمالي الربح</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {profitAnalysis.profitByProduct.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                        لا توجد بيانات كافية للتحليل
                      </TableCell>
                    </TableRow>
                  ) : (
                    profitAnalysis.profitByProduct.map((product) => (
                      <TableRow key={product.id}>
                        <TableCell className="font-medium">
                          {product.name}
                          <div className="text-xs text-muted-foreground">{product.unitsSold} وحدة مباعة</div>
                        </TableCell>
                        <TableCell>{product.costPerUnit.toLocaleString('ar-YE')}</TableCell>
                        <TableCell>{product.sellingPrice.toLocaleString('ar-YE')}</TableCell>
                        <TableCell className="text-primary font-medium">
                          {product.profitPerUnit.toLocaleString('ar-YE')}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-bold w-12">{product.marginPercent.toFixed(1)}%</span>
                            <Progress 
                              value={product.marginPercent} 
                              max={100} 
                              className={`h-2 w-16 ${
                                product.marginPercent > 40 ? 'bg-green-100 [&>div]:bg-green-600' : 
                                product.marginPercent > 20 ? 'bg-yellow-100 [&>div]:bg-yellow-500' : 
                                'bg-red-100 [&>div]:bg-red-500'
                              }`} 
                            />
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className={
                            product.roiPercent > 50 ? 'text-green-600 border-green-200 bg-green-50' :
                            product.roiPercent > 25 ? 'text-yellow-600 border-yellow-200 bg-yellow-50' :
                            'text-red-600 border-red-200 bg-red-50'
                          }>
                            {product.roiPercent.toFixed(0)}%
                          </Badge>
                        </TableCell>
                        <TableCell className="font-bold text-primary">
                          {product.profit.toLocaleString('ar-YE')}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default Profits;
