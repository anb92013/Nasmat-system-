import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Product, Sale, Purchase, User, Supplier, Expense } from '@/types';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';

interface AppContextType {
  products: Product[];
  sales: Sale[];
  purchases: Purchase[];
  suppliers: Supplier[];
  expenses: Expense[];
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (username: string, password: string) => boolean;
  logout: () => void;
  addProduct: (product: Product) => Promise<void>;
  updateProduct: (id: string, product: Partial<Product>) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  addSale: (sale: Sale) => Promise<void>;
  addPurchase: (purchase: Purchase) => Promise<void>;
  addSupplier: (supplier: Supplier) => Promise<void>;
  updateSupplier: (id: string, supplier: Partial<Supplier>) => Promise<void>;
  deleteSupplier: (id: string) => Promise<void>;
  addExpense: (expense: Expense) => Promise<void>;
  deleteExpense: (id: string) => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Helper to map DB snake_case to App camelCase
const mapProductFromDB = (item: any): Product => ({
  id: item.id,
  name: item.name,
  weightGrams: item.weight_grams,
  costPerGram: item.cost_per_gram,
  purchaseCost: item.purchase_cost,
  labelCost: item.label_cost,
  packagingBagCost: item.packaging_bag_cost,
  wrapBagCost: item.wrap_bag_cost,
  workerCost: item.worker_cost,
  netPurchaseCost: item.net_purchase_cost,
  extras5Percent: item.extras_5_percent,
  sale5Percent: item.sale_5_percent,
  profit35Percent: item.profit_35_percent,
  sellingPrice: item.selling_price,
  quantity: item.quantity,
  category: item.category,
  createdAt: new Date(item.created_at),
});

const mapProductToDB = (item: Product) => ({
  id: item.id,
  name: item.name,
  weight_grams: item.weightGrams,
  cost_per_gram: item.costPerGram,
  purchase_cost: item.purchaseCost,
  label_cost: item.labelCost,
  packaging_bag_cost: item.packagingBagCost,
  wrap_bag_cost: item.wrapBagCost,
  worker_cost: item.workerCost,
  net_purchase_cost: item.netPurchaseCost,
  extras_5_percent: item.extras5Percent,
  sale_5_percent: item.sale5Percent,
  profit_35_percent: item.profit35Percent,
  selling_price: item.sellingPrice,
  quantity: item.quantity,
  category: item.category,
  created_at: item.createdAt.toISOString(),
});

const mapSaleFromDB = (item: any): Sale => ({
  id: item.id,
  productId: item.product_id,
  productName: item.product_name,
  quantity: item.quantity,
  unitPrice: item.unit_price,
  totalPrice: item.total_price,
  profit: item.profit,
  date: new Date(item.date),
});

const mapSaleToDB = (item: Sale) => ({
  id: item.id,
  product_id: item.productId,
  product_name: item.productName,
  quantity: item.quantity,
  unit_price: item.unitPrice,
  total_price: item.totalPrice,
  profit: item.profit,
  date: item.date.toISOString(),
});

const mapPurchaseFromDB = (item: any): Purchase => ({
  id: item.id,
  productId: item.product_id,
  productName: item.product_name,
  quantity: item.quantity,
  unitCost: item.unit_cost,
  totalCost: item.total_cost,
  supplierId: item.supplier_id,
  supplier: item.supplier_name,
  date: new Date(item.date),
});

const mapPurchaseToDB = (item: Purchase) => ({
  id: item.id,
  product_id: item.productId,
  product_name: item.productName,
  quantity: item.quantity,
  unit_cost: item.unitCost,
  total_cost: item.totalCost,
  supplier_id: item.supplierId,
  supplier_name: item.supplier,
  date: item.date.toISOString(),
});

const mapSupplierFromDB = (item: any): Supplier => ({
  id: item.id,
  name: item.name,
  phone: item.phone,
  address: item.address,
  notes: item.notes,
  createdAt: new Date(item.created_at),
});

const mapSupplierToDB = (item: Supplier) => ({
  id: item.id,
  name: item.name,
  phone: item.phone,
  address: item.address,
  notes: item.notes,
  created_at: item.createdAt.toISOString(),
});

const mapExpenseFromDB = (item: any): Expense => ({
  id: item.id,
  title: item.title,
  amount: item.amount,
  category: item.category,
  notes: item.notes,
  date: new Date(item.date),
});

const mapExpenseToDB = (item: Expense) => ({
  id: item.id,
  title: item.title,
  amount: item.amount,
  category: item.category,
  notes: item.notes,
  date: item.date.toISOString(),
});

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('nasmat_user');
    return saved ? JSON.parse(saved) : null;
  });

  const fetchData = async () => {
    setIsLoading(true);
    try {
      // Fetch Products
      const { data: productsData, error: productsError } = await supabase
        .from('products')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (productsError) throw productsError;
      if (productsData) setProducts(productsData.map(mapProductFromDB));

      // Fetch Sales
      const { data: salesData, error: salesError } = await supabase
        .from('sales')
        .select('*')
        .order('date', { ascending: false });
      
      if (salesError) throw salesError;
      if (salesData) setSales(salesData.map(mapSaleFromDB));

      // Fetch Purchases
      const { data: purchasesData, error: purchasesError } = await supabase
        .from('purchases')
        .select('*')
        .order('date', { ascending: false });
      
      if (purchasesError) throw purchasesError;
      if (purchasesData) setPurchases(purchasesData.map(mapPurchaseFromDB));

      // Fetch Suppliers
      const { data: suppliersData, error: suppliersError } = await supabase
        .from('suppliers')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (suppliersError) throw suppliersError;
      if (suppliersData) setSuppliers(suppliersData.map(mapSupplierFromDB));

      // Fetch Expenses
      const { data: expensesData, error: expensesError } = await supabase
        .from('expenses')
        .select('*')
        .order('date', { ascending: false });
      
      if (expensesError) throw expensesError;
      if (expensesData) setExpenses(expensesData.map(mapExpenseFromDB));

    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('حدث خطأ أثناء جلب البيانات');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const login = (username: string, password: string): boolean => {
    if (username === 'admin' && password === 'admin123') {
      const newUser: User = { id: '1', username: 'admin', role: 'admin' };
      setUser(newUser);
      localStorage.setItem('nasmat_user', JSON.stringify(newUser));
      return true;
    }
    if (username === 'user' && password === 'user123') {
      const newUser: User = { id: '2', username: 'user', role: 'user' };
      setUser(newUser);
      localStorage.setItem('nasmat_user', JSON.stringify(newUser));
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('nasmat_user');
  };

  const addProduct = async (product: Product) => {
    try {
      // Ensure ID is UUID if possible, or rely on DB generation. 
      // Here we use client-generated ID but ensure it's compatible if DB expects UUID.
      // For now, assuming the schema uses text for ID or we generate a valid UUID.
      const dbProduct = mapProductToDB(product);
      const { data, error } = await supabase.from('products').insert(dbProduct).select().single();
      
      if (error) throw error;
      if (data) {
        setProducts(prev => [mapProductFromDB(data), ...prev]);
      }
    } catch (error) {
      console.error('Error adding product:', error);
      toast.error('فشل إضافة المنتج');
      throw error;
    }
  };

  const updateProduct = async (id: string, updates: Partial<Product>) => {
    try {
      // Map updates to snake_case
      const dbUpdates: any = {};
      if (updates.name) dbUpdates.name = updates.name;
      if (updates.quantity !== undefined) dbUpdates.quantity = updates.quantity;
      if (updates.sellingPrice !== undefined) dbUpdates.selling_price = updates.sellingPrice;
      // ... map other fields as needed for updates
      // For full update support, we should map all fields.
      // A simpler way for now:
      const currentProduct = products.find(p => p.id === id);
      if (!currentProduct) return;
      
      const mergedProduct = { ...currentProduct, ...updates };
      const dbProduct = mapProductToDB(mergedProduct);
      
      const { error } = await supabase.from('products').update(dbProduct).eq('id', id);
      
      if (error) throw error;
      
      setProducts(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
    } catch (error) {
      console.error('Error updating product:', error);
      toast.error('فشل تحديث المنتج');
      throw error;
    }
  };

  const deleteProduct = async (id: string) => {
    try {
      const { error } = await supabase.from('products').delete().eq('id', id);
      if (error) throw error;
      setProducts(prev => prev.filter(p => p.id !== id));
    } catch (error) {
      console.error('Error deleting product:', error);
      toast.error('فشل حذف المنتج');
      throw error;
    }
  };

  const addSale = async (sale: Sale) => {
    try {
      const dbSale = mapSaleToDB(sale);
      const { data, error } = await supabase.from('sales').insert(dbSale).select().single();
      
      if (error) throw error;
      if (data) {
        setSales(prev => [mapSaleFromDB(data), ...prev]);
        
        // Update product quantity
        const product = products.find(p => p.id === sale.productId);
        if (product) {
          await updateProduct(sale.productId, { quantity: product.quantity - sale.quantity });
        }
      }
    } catch (error) {
      console.error('Error adding sale:', error);
      toast.error('فشل تسجيل البيع');
      throw error;
    }
  };

  const addPurchase = async (purchase: Purchase) => {
    try {
      const dbPurchase = mapPurchaseToDB(purchase);
      const { data, error } = await supabase.from('purchases').insert(dbPurchase).select().single();
      
      if (error) throw error;
      if (data) {
        setPurchases(prev => [mapPurchaseFromDB(data), ...prev]);
        
        // Update product quantity
        const product = products.find(p => p.id === purchase.productId);
        if (product) {
          await updateProduct(purchase.productId, { quantity: product.quantity + purchase.quantity });
        }
      }
    } catch (error) {
      console.error('Error adding purchase:', error);
      toast.error('فشل تسجيل الشراء');
      throw error;
    }
  };

  const addSupplier = async (supplier: Supplier) => {
    try {
      const dbSupplier = mapSupplierToDB(supplier);
      const { data, error } = await supabase.from('suppliers').insert(dbSupplier).select().single();
      
      if (error) throw error;
      if (data) {
        setSuppliers(prev => [mapSupplierFromDB(data), ...prev]);
      }
    } catch (error) {
      console.error('Error adding supplier:', error);
      toast.error('فشل إضافة المورد');
      throw error;
    }
  };

  const updateSupplier = async (id: string, updates: Partial<Supplier>) => {
    try {
      const currentSupplier = suppliers.find(s => s.id === id);
      if (!currentSupplier) return;
      
      const merged = { ...currentSupplier, ...updates };
      const dbSupplier = mapSupplierToDB(merged);
      
      const { error } = await supabase.from('suppliers').update(dbSupplier).eq('id', id);
      
      if (error) throw error;
      setSuppliers(prev => prev.map(s => s.id === id ? { ...s, ...updates } : s));
    } catch (error) {
      console.error('Error updating supplier:', error);
      toast.error('فشل تحديث المورد');
      throw error;
    }
  };

  const deleteSupplier = async (id: string) => {
    try {
      const { error } = await supabase.from('suppliers').delete().eq('id', id);
      if (error) throw error;
      setSuppliers(prev => prev.filter(s => s.id !== id));
    } catch (error) {
      console.error('Error deleting supplier:', error);
      toast.error('فشل حذف المورد');
      throw error;
    }
  };

  const addExpense = async (expense: Expense) => {
    try {
      const dbExpense = mapExpenseToDB(expense);
      const { data, error } = await supabase.from('expenses').insert(dbExpense).select().single();
      
      if (error) throw error;
      if (data) {
        setExpenses(prev => [mapExpenseFromDB(data), ...prev]);
      }
    } catch (error) {
      console.error('Error adding expense:', error);
      toast.error('فشل إضافة المصروف');
      throw error;
    }
  };

  const deleteExpense = async (id: string) => {
    try {
      const { error } = await supabase.from('expenses').delete().eq('id', id);
      if (error) throw error;
      setExpenses(prev => prev.filter(e => e.id !== id));
    } catch (error) {
      console.error('Error deleting expense:', error);
      toast.error('فشل حذف المصروف');
      throw error;
    }
  };

  return (
    <AppContext.Provider value={{
      products,
      sales,
      purchases,
      suppliers,
      expenses,
      user,
      isAuthenticated: !!user,
      isLoading,
      login,
      logout,
      addProduct,
      updateProduct,
      deleteProduct,
      addSale,
      addPurchase,
      addSupplier,
      updateSupplier,
      deleteSupplier,
      addExpense,
      deleteExpense,
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
