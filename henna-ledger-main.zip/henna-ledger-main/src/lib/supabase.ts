import { createClient } from '@supabase/supabase-js';

// ملاحظة: يجب عليك إنشاء ملف .env وإضافة مفاتيح Supabase الخاصة بك
// VITE_SUPABASE_URL=your_project_url
// VITE_SUPABASE_ANON_KEY=your_anon_key

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// دوال مساعدة للتعامل مع قاعدة البيانات
export const db = {
  products: {
    async getAll() {
      const { data, error } = await supabase.from('products').select('*');
      if (error) throw error;
      return data;
    },
    async create(product: any) {
      const { data, error } = await supabase.from('products').insert(product).select();
      if (error) throw error;
      return data;
    }
  },
  // يمكن إضافة باقي الدوال (sales, purchases, etc.) هنا بنفس الطريقة
};
