export interface Product {
  id: string;
  name: string;
  weightGrams: number;
  costPerGram: number;
  purchaseCost: number;
  labelCost: number;
  packagingBagCost: number;
  wrapBagCost: number;
  workerCost: number;
  netPurchaseCost: number;
  extras5Percent: number;
  sale5Percent: number;
  profit35Percent: number;
  sellingPrice: number;
  quantity: number;
  category: string; // Changed from union type to string to allow custom categories
  createdAt: Date;
}

export interface Sale {
  id: string;
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  profit: number;
  date: Date;
}

export interface Purchase {
  id: string;
  productId: string;
  productName: string;
  quantity: number;
  unitCost: number;
  totalCost: number;
  supplierId?: string;
  supplier?: string;
  date: Date;
}

export interface Supplier {
  id: string;
  name: string;
  phone: string;
  address?: string;
  notes?: string;
  createdAt: Date;
}

export interface Expense {
  id: string;
  title: string;
  amount: number;
  category: 'rent' | 'electricity' | 'salaries' | 'maintenance' | 'marketing' | 'other';
  date: Date;
  notes?: string;
}

export interface DailyReport {
  date: Date;
  totalSales: number;
  totalPurchases: number;
  netProfit: number;
  salesCount: number;
  purchasesCount: number;
}

export interface User {
  id: string;
  username: string;
  role: 'admin' | 'user';
}
