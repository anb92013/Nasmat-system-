const { app, BrowserWindow } = require('electron');
const path = require('path');

// Handle creating/removing shortcuts on Windows when installing/uninstalling.
if (require('electron-squirrel-startup')) {
  app.quit();
}

function createWindow() {
  // Create the browser window.
  const mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      nodeIntegration: true,
      contextIsolation: false, // For simple local apps
    },
    icon: path.join(__dirname, '../public/favicon.ico') // أيقونة التطبيق
  });

  // في وضع التطوير، نقوم بتحميل الرابط المحلي
  // في وضع الإنتاج (بعد البناء)، نقوم بتحميل ملف index.html
  const isDev = process.env.NODE_ENV === 'development';
  
  if (isDev) {
    mainWindow.loadURL('http://localhost:8080');
    mainWindow.webContents.openDevTools(); // فتح أدوات المطور للتصحيح
  } else {
    // استخدام مسار الملف المحلي في الإنتاج
    mainWindow.loadFile(path.join(__dirname, '../dist/index.html'));
  }
  
  // إزالة القائمة العلوية الافتراضية للتطبيق لجعله يبدو احترافياً
  mainWindow.setMenuBarVisibility(false);
}

app.whenReady().then(() => {
  createWindow();

  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit();
});
