/*
  # Initial Database Schema for Nasmat Sharqiya

  ## Query Description:
  This migration creates the initial tables required for the inventory management system.
  It sets up tables for products, sales, purchases, suppliers, and expenses, mirroring the
  structure used in the frontend application.

  ## Metadata:
  - Schema-Category: "Structural"
  - Impact-Level: "High"
  - Requires-Backup: false
  - Reversible: true

  ## Structure Details:
  - Tables created: products, sales, purchases, suppliers, expenses
  - RLS enabled on all tables
  - Policies added for public access (anon role) to facilitate easy transition from LocalStorage

  ## Security Implications:
  - RLS Status: Enabled
  - Policy Changes: Added public access policies for anon key usage.
*/

-- Create Products Table
CREATE TABLE IF NOT EXISTS public.products (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    weight_grams NUMERIC,
    cost_per_gram NUMERIC,
    purchase_cost NUMERIC,
    label_cost NUMERIC,
    packaging_bag_cost NUMERIC,
    wrap_bag_cost NUMERIC,
    worker_cost NUMERIC,
    net_purchase_cost NUMERIC,
    extras_5_percent NUMERIC,
    sale_5_percent NUMERIC,
    profit_35_percent NUMERIC,
    selling_price NUMERIC,
    quantity INTEGER DEFAULT 0,
    category TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- Create Sales Table
CREATE TABLE IF NOT EXISTS public.sales (
    id TEXT PRIMARY KEY,
    product_id TEXT REFERENCES public.products(id),
    product_name TEXT,
    quantity INTEGER,
    unit_price NUMERIC,
    total_price NUMERIC,
    profit NUMERIC,
    date TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- Create Suppliers Table
CREATE TABLE IF NOT EXISTS public.suppliers (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    phone TEXT,
    address TEXT,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- Create Purchases Table
CREATE TABLE IF NOT EXISTS public.purchases (
    id TEXT PRIMARY KEY,
    product_id TEXT REFERENCES public.products(id),
    product_name TEXT,
    quantity INTEGER,
    unit_cost NUMERIC,
    total_cost NUMERIC,
    supplier_id TEXT REFERENCES public.suppliers(id),
    supplier TEXT,
    date TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- Create Expenses Table
CREATE TABLE IF NOT EXISTS public.expenses (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    amount NUMERIC NOT NULL,
    category TEXT,
    notes TEXT,
    date TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- Enable Row Level Security (RLS)
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sales ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.suppliers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.expenses ENABLE ROW LEVEL SECURITY;

-- Create Policies to allow access via Anon Key (since we are migrating from LocalStorage logic)
-- In a more advanced setup, we would restrict this to authenticated users.

-- Products Policies
CREATE POLICY "Enable read access for all users" ON public.products FOR SELECT USING (true);
CREATE POLICY "Enable insert access for all users" ON public.products FOR INSERT WITH CHECK (true);
CREATE POLICY "Enable update access for all users" ON public.products FOR UPDATE USING (true);
CREATE POLICY "Enable delete access for all users" ON public.products FOR DELETE USING (true);

-- Sales Policies
CREATE POLICY "Enable read access for all users" ON public.sales FOR SELECT USING (true);
CREATE POLICY "Enable insert access for all users" ON public.sales FOR INSERT WITH CHECK (true);
CREATE POLICY "Enable update access for all users" ON public.sales FOR UPDATE USING (true);
CREATE POLICY "Enable delete access for all users" ON public.sales FOR DELETE USING (true);

-- Purchases Policies
CREATE POLICY "Enable read access for all users" ON public.purchases FOR SELECT USING (true);
CREATE POLICY "Enable insert access for all users" ON public.purchases FOR INSERT WITH CHECK (true);
CREATE POLICY "Enable update access for all users" ON public.purchases FOR UPDATE USING (true);
CREATE POLICY "Enable delete access for all users" ON public.purchases FOR DELETE USING (true);

-- Suppliers Policies
CREATE POLICY "Enable read access for all users" ON public.suppliers FOR SELECT USING (true);
CREATE POLICY "Enable insert access for all users" ON public.suppliers FOR INSERT WITH CHECK (true);
CREATE POLICY "Enable update access for all users" ON public.suppliers FOR UPDATE USING (true);
CREATE POLICY "Enable delete access for all users" ON public.suppliers FOR DELETE USING (true);

-- Expenses Policies
CREATE POLICY "Enable read access for all users" ON public.expenses FOR SELECT USING (true);
CREATE POLICY "Enable insert access for all users" ON public.expenses FOR INSERT WITH CHECK (true);
CREATE POLICY "Enable update access for all users" ON public.expenses FOR UPDATE USING (true);
CREATE POLICY "Enable delete access for all users" ON public.expenses FOR DELETE USING (true);
