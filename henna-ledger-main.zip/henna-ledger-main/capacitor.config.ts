import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.nasmat.app',
  appName: 'نسمات شرقية',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    // إعدادات إضافية للملحقات إذا لزم الأمر
  }
};

export default config;
