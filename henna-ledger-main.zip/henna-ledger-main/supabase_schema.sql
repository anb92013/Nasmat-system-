-- هذا الملف يحتوي على أوامر SQL لإنشاء قاعدة البيانات في Supabase
-- قم بنسخ هذا المحتوى وتشغيله في SQL Editor في لوحة تحكم Supabase

-- 1. جدول المنتجات (Products)
CREATE TABLE products (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  weight_grams NUMERIC,
  cost_per_gram NUMERIC,
  purchase_cost NUMERIC,
  label_cost NUMERIC,
  packaging_bag_cost NUMERIC,
  wrap_bag_cost NUMERIC,
  worker_cost NUMERIC,
  net_purchase_cost NUMERIC,
  extras_5_percent NUMERIC,
  sale_5_percent NUMERIC,
  profit_35_percent NUMERIC,
  selling_price NUMERIC,
  quantity INTEGER DEFAULT 0,
  category TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- 2. جدول المبيعات (Sales)
CREATE TABLE sales (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id UUID REFERENCES products(id),
  product_name TEXT,
  quantity INTEGER,
  unit_price NUMERIC,
  total_price NUMERIC,
  profit NUMERIC,
  date TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- 3. جدول المشتريات (Purchases)
CREATE TABLE purchases (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id UUID REFERENCES products(id),
  product_name TEXT,
  quantity INTEGER,
  unit_cost NUMERIC,
  total_cost NUMERIC,
  supplier_id UUID, -- يمكن ربطه بجدول الموردين لاحقاً
  supplier_name TEXT,
  date TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- 4. جدول الموردين (Suppliers)
CREATE TABLE suppliers (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT,
  address TEXT,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- 5. جدول المصروفات (Expenses)
CREATE TABLE expenses (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  amount NUMERIC NOT NULL,
  category TEXT,
  notes TEXT,
  date TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- تفعيل Row Level Security (اختياري للحماية)
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;
ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;

-- سياسات بسيطة للسماح بالقراءة والكتابة للجميع (يمكن تعديلها لاحقاً)
CREATE POLICY "Allow public access" ON products FOR ALL USING (true);
CREATE POLICY "Allow public access" ON sales FOR ALL USING (true);
CREATE POLICY "Allow public access" ON purchases FOR ALL USING (true);
CREATE POLICY "Allow public access" ON suppliers FOR ALL USING (true);
CREATE POLICY "Allow public access" ON expenses FOR ALL USING (true);
